package com.example.andriod.myauthapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class LoginActivity extends AppCompatActivity  implements
        SharedPreferences.OnSharedPreferenceChangeListener{
    private EditText nameText;
    private EditText mobileNo;
    private Button loginButton;
    private Boolean mUser;
    private String mUserId;
    private RequestQueue mQueue;
    private static final String TAG = LoginActivity.class.getSimpleName();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
        mobileNo=findViewById(R.id.mobileno);
        mQueue =Volley.newRequestQueue(this);
        loginButton=findViewById(R.id.loginbutton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = mobileNo.getText().toString();

                String url = "http://192.168.1.100:5000/userinfo/"+number;
                Log.d(TAG,url);
                final RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    JSONObject resultObject = response.getJSONObject("output");
                                    int result = resultObject.getInt("result");
                                    int None=0;
                                    Log.d(TAG,String.valueOf(result==None));
                                    if(result==None){
                                        Log.d(TAG," no entries");
                                        mUser=false;
                                        post();
                                        get();
                                    }
                                    else {
                                        Log.d(TAG," entry found");
                                        mUser=true;

                                        get();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                requestQueue.add(jsonObjectRequest);
            }
        });

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.registerOnSharedPreferenceChangeListener(LoginActivity.this);



    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
    }

    public void post(){


        try {
            RequestQueue requestQueue2 = Volley.newRequestQueue(LoginActivity.this);
            String URL = "http://192.168.1.100:5000/userinfo";
            Log.d(TAG,URL);
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("username", "guest");
            jsonBody.put("mobileno", mobileNo.getText());
            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("LOG_VOLLEY",response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("LOG_VOLLEY", error.toString());
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {

                        responseString = String.valueOf(response.statusCode);

                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue2.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public void get(){
        String number = mobileNo.getText().toString();
        String url = "http://192.168.1.100:5000/userinfo/"+number;
        Log.d(TAG,url);
        final RequestQueue requestQueue3 = Volley.newRequestQueue(LoginActivity.this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject resultObject = response.getJSONObject("output");
                            String resultId = resultObject.getString("id");
                            PrefrenceData.setUserId(LoginActivity.this, resultId);
                            Intent home = new Intent(LoginActivity.this,MainActivity.class);
                            startActivity(home);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue3.add(jsonObjectRequest);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.unregisterOnSharedPreferenceChangeListener(this);
    }
}
