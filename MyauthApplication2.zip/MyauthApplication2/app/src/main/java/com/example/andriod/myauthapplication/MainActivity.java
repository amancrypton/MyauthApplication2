package com.example.andriod.myauthapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
    private TextView userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userId=findViewById(R.id.user_id);
        //PrefrenceData.setUserId(this, "1");
        updateUserId();

    }




     public void updateUserId(){
        userId.setText(PrefrenceData.getUserId(this));
     }
}
